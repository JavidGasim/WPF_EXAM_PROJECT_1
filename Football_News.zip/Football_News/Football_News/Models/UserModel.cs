﻿namespace Football_News.Models
{
    public class UserModel
    {
        public string? Name { get; set; }
        public string? Surname { get; set; }
        public string? Gmail { get; set; }
        public string? Password { get; set; }
        public string? BirthdayDate { get; set; }

        public UserModel()
        {

        }

        public UserModel(string? name, string? surname, string? gmail, string? password, string? birthdayDate)
        {
            Name = name;
            Surname = surname;
            Gmail = gmail;
            Password = password;
            BirthdayDate = birthdayDate;
        }
    }
}
