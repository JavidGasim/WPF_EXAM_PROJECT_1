﻿namespace Football_News.Models;

public class SharerModel
{
    public string? Name { get; set; }
    public string? Surname { get; set; }
    public string? Gmail { get; set; }
    public string? Password { get; set; }
    public string? BirthdayDate { get; set; }

    public SharerModel()
    {

    }

    public SharerModel(string? name, string? surname, string? gmail, string? password, string? birthdayDate)
    {
        Name = name;
        Surname = surname;
        Gmail = gmail;
        Password = password;
        BirthdayDate = birthdayDate;
    }
}
