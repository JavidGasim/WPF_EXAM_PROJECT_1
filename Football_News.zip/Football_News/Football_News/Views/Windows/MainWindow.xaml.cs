﻿using System.Windows;
using System.Windows.Navigation;

namespace Football_News.Views.Windows
{
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
