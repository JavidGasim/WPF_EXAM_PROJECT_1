﻿using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class SharerNewsPage : Page
    {
        public SharerNewsPage()
        {
            InitializeComponent();
        }

        private void exit_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new MainPage());
        }

        private void all_news_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new UserNewsPage());
        }
    }
}
