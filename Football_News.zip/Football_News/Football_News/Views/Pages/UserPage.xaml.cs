﻿using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class UserPage : Page
    {
        public UserPage()
        {
            InitializeComponent();
        }

        private void User_Register_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new UserRegisterPage());
        }

        private void User_GoMain_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new MainPage());
        }

        private void User_SignIn_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new UserSignInPage());
        }
    }
}
