﻿using Football_News.Models;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class SharerSignInPage : Page
    {
        List<SharerModel> sharerModels;
        public SharerSignInPage()
        {
            InitializeComponent();
        }

        private void mail_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (mail_txtbox.Text == "")
            {
                mail_lbl.Content = "Your Mail";
            }
            else
            {
                mail_lbl.Content = string.Empty;
            }
        }

        private void pass_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (pass_txtbox.Text == "")
            {
                pass_lbl.Content = "Your Mail";
            }
            else
            {
                pass_lbl.Content = string.Empty;
            }
        }

        private void sign_in_btn_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string jsontxt = File.ReadAllText("../../../DataBase/Sharers.json");
            var list = JsonSerializer.Deserialize<List<SharerModel>>(jsontxt);

            for (int i = 0; i < list.Count; i++)
            {
                if (mail_txtbox.Text == list[i].Gmail && pass_txtbox.Text == list[i].Password)
                {
                    this.NavigationService.Navigate(new SharerNewsPage());
                }

                else
                {
                    MessageBox.Show("Incorrect Mail or Password");
                }
            }
        }
    }
}
