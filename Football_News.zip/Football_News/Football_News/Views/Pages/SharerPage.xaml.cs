﻿using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class SharerPage : Page
    {
        public SharerPage()
        {
            InitializeComponent();
        }

        private void Sharer_GoMain_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new MainPage());
        }

        private void Sharer_Register_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new SharerRegisterPage());
        }

        private void Sharer_SignIn_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new SharerSignInPage());
        }
    }
}
