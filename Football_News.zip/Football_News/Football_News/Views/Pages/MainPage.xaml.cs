﻿using Football_News.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            this.DataContext = new MainPageModel();
        }

        //public void Sharer_btn_Click(object sender, RoutedEventArgs e)
        //{
        //    this.NavigationService.Navigate(new SharerPage());
        //}

        public void User_btn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new UserPage());
        }
    }
}
