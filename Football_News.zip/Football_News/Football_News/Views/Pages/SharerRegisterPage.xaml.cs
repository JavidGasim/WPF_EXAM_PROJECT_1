﻿using Football_News.Models;
using System.Windows;
using System.Windows.Controls;

namespace Football_News.Views.Pages
{
    public partial class SharerRegisterPage : Page
    {
        public SharerModel model = new SharerModel();
        public SharerRegisterPage()
        {
            InitializeComponent();
        }

        private void nxt_btn_Click(object sender, RoutedEventArgs e)
        {
            if (Name_txtbox.Text != "" && Surname_txtbox.Text != "" && Gmail_txtbox.Text != "" && Password_txtbox.Text != "" && birthday_picker.Text != "")
            {

                model.Name = Name_txtbox.Text;
                model.Surname = Surname_txtbox.Text;
                model.Gmail = Gmail_txtbox.Text;
                model.Password = Password_txtbox.Text;
                model.BirthdayDate = birthday_picker.SelectedDate.ToString();

                GmailConfirmPage confirmPage = new GmailConfirmPage(model);

                this.NavigationService.Navigate(confirmPage);
            }

            else
            {
                MessageBox.Show("Empty Box");
            }
        }

        private void Name_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Name_txtbox.Text == "")
            {
                name_lbl.Content = "Your Name";
            }
            else
            {
                name_lbl.Content = string.Empty;
            }
        }

        private void Surname_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Surname_txtbox.Text == "")
            {
                surname_lbl.Content = "Your Surname";
            }
            else
            {
                surname_lbl.Content = string.Empty;
            }
        }

        private void Gmail_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Gmail_txtbox.Text == "")
            {
                gmail_lbl.Content = "Your Gmail";
            }
            else
            {
                gmail_lbl.Content = string.Empty;
            }
        }

        private void Password_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Password_txtbox.Text == "")
            {
                password_lbl.Content = "Your Password";
            }
            else
            {
                password_lbl.Content = string.Empty;
            }
        }
    }
}
