﻿using System.Net.Mail;
using System.Net;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Windows.Media.Media3D;
using System.Text.Json;
using System.IO;
using Football_News.Models;

namespace Football_News.Views.Pages
{
    public partial class GmailConfirmPage : Page
    {
        List<SharerModel> sharers = new List<SharerModel>();

        static public Random random = new Random();
        int rnd = random.Next(100000, 999999);

        private SharerModel model;
        public GmailConfirmPage(SharerModel model)
        {
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("projectproject611@gmail.com");
            mailMessage.To.Add(model.Gmail);
            mailMessage.Subject = "Football News";
            mailMessage.Body = rnd.ToString();
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "smtp.gmail.com";
            smtpClient.Port = 587;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new NetworkCredential("projectproject611@gmail.com", "xwuv uauv jljd cyni");
            smtpClient.EnableSsl = true;

            try
            {
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                MessageBox.Show("False Proccess");
            }
            InitializeComponent();
            this.model = model;
        }

        private void ok_btn_Click(object sender, RoutedEventArgs e)
        {
            if (code_txtbox.Text == rnd.ToString())
            {
                try
                {
                    string jsontxt = File.ReadAllText("../../../DataBase/Sharers.json");
                    var list = JsonSerializer.Deserialize<List<SharerModel>>(jsontxt);
                    sharers.Clear();

                    if (list.Count > 0)
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            sharers.Add(list[i]);
                        }

                        sharers.Add(model);
                    }

                    else
                    {
                        sharers.Add(model);
                    }

                    JsonSerializerOptions options = new JsonSerializerOptions();
                    options.WriteIndented = true;

                    string jsonstr = JsonSerializer.Serialize(sharers, options);
                    File.WriteAllText("../../../DataBase/Sharers.json", jsonstr);

                    MessageBox.Show("Successfully Registration");
                    this.NavigationService.Navigate(new MainPage());
                }
                catch (Exception)
                {
                    sharers.Add(model);

                    JsonSerializerOptions options = new JsonSerializerOptions();
                    options.WriteIndented = true;

                    string jsonstr = JsonSerializer.Serialize(sharers, options);
                    File.WriteAllText("../../../DataBase/Sharers.json", jsonstr);

                    MessageBox.Show("Successfully Registration");
                    this.NavigationService.Navigate(new MainPage());
                }

                
            }

            else if (code_txtbox.Text == "")
            {
                MessageBox.Show("Empty Box");
            }

            else
            {


                this.NavigationService.Navigate(new GmailConfirmPage(model));
            }
        }

        private void code_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (code_txtbox.Text == "")
            {
                send_code_lbl.Content = "SEND CODE";
            }
            else
            {
                send_code_lbl.Content = string.Empty;

            }
        }
    }
}
