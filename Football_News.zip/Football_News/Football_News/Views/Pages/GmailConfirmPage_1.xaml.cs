﻿using System.Collections.Generic;
using System.Net.Mail;
using System.Net;
using System.Text.Json;
using System.Windows;
using System;
using System.Windows.Controls;
using System.IO;
using Football_News.Models;
using Football_News.ViewModels;

namespace Football_News.Views.Pages
{
    public partial class GmailConfirmPage_1 : Page
    {
        List<UserModel> users = new List<UserModel>();

        static public Random random = new Random();
        int rnd = random.Next(100000, 999999);

        private UserModel model;

        MailMessage mailMessage = new MailMessage();

        public GmailConfirmPage_1(UserModel model)
        {
            mailMessage.From = new MailAddress("projectproject611@gmail.com");
            mailMessage.To.Add(model.Gmail);
            mailMessage.Subject = "Football News";
            mailMessage.Body = rnd.ToString();
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "smtp.gmail.com";
            smtpClient.Port = 587;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new NetworkCredential("projectproject611@gmail.com", "xwuv uauv jljd cyni");
            smtpClient.EnableSsl = true;

            try
            {
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                MessageBox.Show("False Proccess");
            }

            this.model = model;
            InitializeComponent();
        }

        private void ok_btn_Click(object sender, RoutedEventArgs e)
        {
            if (code_txtbox.Text == rnd.ToString())
            {


                try
                {
                    string jsontxt = File.ReadAllText("../../../DataBase/Users.json");
                    var list = JsonSerializer.Deserialize<List<UserModel>>(jsontxt);
                    users.Clear();

                    if (list.Count > 0)
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            users.Add(list[i]);
                        }

                        users.Add(model);
                    }

                    else
                    {
                        users.Add(model);
                    }

                    JsonSerializerOptions options = new JsonSerializerOptions();
                    options.WriteIndented = true;

                    string jsonstr = JsonSerializer.Serialize(users, options);
                    File.WriteAllText("../../../DataBase/Users.json", jsonstr);

                    MessageBox.Show("Successfully Registration");
                    this.NavigationService.Navigate(new MainPage());
                }
                catch (Exception)
                {
                    users.Add(model);

                    JsonSerializerOptions options = new JsonSerializerOptions();
                    options.WriteIndented = true;

                    string jsonstr = JsonSerializer.Serialize(users, options);
                    File.WriteAllText("../../../DataBase/Users.json", jsonstr);

                    MessageBox.Show("Successfully Registration");
                    this.NavigationService.Navigate(new MainPage());
                }

            }

            else if (code_txtbox.Text == "")
            {
                MessageBox.Show("Empty Box");
            }

            else
            {


                this.NavigationService.Navigate(new GmailConfirmPage_1(model));
            }
        }

        private void code_txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (code_txtbox.Text == "")
            {
                send_code_lbl.Content = "SEND CODE";
            }
            else
            {
                send_code_lbl.Content = string.Empty;

            }
        }
    }
}
