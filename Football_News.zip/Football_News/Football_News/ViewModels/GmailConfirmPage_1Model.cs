﻿using Football_News.Models;
using System.Collections.Generic;
using System;
using System.Net.Mail;
using System.Net;
using System.Windows;

namespace Football_News.ViewModels
{
    public class GmailConfirmPage_1Model
    {
        

        public GmailConfirmPage_1Model()
        {
        }
    }
}
