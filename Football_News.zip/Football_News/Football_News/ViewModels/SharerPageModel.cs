﻿namespace Football_News.ViewModels
{
    public class SharerPageModel
    {
    }
}
