﻿using Football_News.Commands;
using Football_News.Views.Pages;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Football_News.ViewModels
{
    public class MainPageModel
    {
        public ICommand sharecommand { get; set; }
        public MainPageModel()
        {
            sharecommand = new RelayCommand(share);
        }

        public void share(object? param)
        {
            var page = param as Page;
            page.NavigationService.Navigate(new SharerPage());
        }
    }
}
