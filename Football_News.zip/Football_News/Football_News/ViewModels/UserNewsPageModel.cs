﻿namespace Football_News.ViewModels
{
    public class UserNewsPageModel
    {
    }
}
